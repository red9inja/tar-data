#!/usr/bin/python
import base64
import os
## ec2 instances
primary_server_ip="3.1.126.19"
primary_ip_allocation_id="eipalloc-028d5758d00495a3a"
primary_aws_name_tag="shopify-server-test-primary"
staging_server_ip="18.140.226.113"
staging_ip_allocation_id="eipalloc-0b61ed92c84b1d414"
staging_aws_name_tag="staging-shopify-auction"
old_aws_name_tag="old-shopify-auction-server"
aws_name_tag="tmp-shopify-auction-server"

## ec2 instance parameters
aws_region="ap-southeast-1"
aws_security_group="sg-07342adfaf18bc1c5"
aws_instance_type="t2.micro"
aws_subnet="subnet-924095f4"
aws_key="jul2024"

## ec2 ami
ami_prefix="ami-shopify-server-test"

## launch configuration
launch_configuration="launch-template-shopify-server"

## autoscaled instance user data
user_data="""#!/bin/bash
 
crontab -u shopify-auction -r
hostname shopify-auction-autoscaled
echo  " " > /home/shopify-auction/.ssh/id_rsa.pub
echo "shopify-auction-autoscaled" > /etc/hostname """

## primary instance user data
primary_user_data="""Content-Type: multipart/mixed; boundary="//"
MIME-Version: 1.0

--//
Content-Type: text/cloud-config; charset="us-ascii"
MIME-Version: 1.0
Content-Transfer-Encoding: 7bit
Content-Disposition: attachment; filename="cloud-config.txt"

#cloud-config
cloud_final_modules:
- [scripts-user, always]

--//
Content-Type: text/x-shellscript; charset="us-ascii"
MIME-Version: 1.0
Content-Transfer-Encoding: 7bit
Content-Disposition: attachment; filename="userdata.txt"

#!/bin/bash

touch /var/spool/cron/crontabs/shopify-auction; chmod 600 /var/spool/cron/crontabs/shopify-auction; chown shopify-auction:crontab /var/spool/cron/crontabs/shopify-auction
cat <<EOF > /var/spool/cron/crontabs/shopify-auction
## add crons below

11 9 * * * /home/shopify-auction/MODIF/./log_checker                   ## <-- Add shopify-auction crons here
0 */1 * * * /usr/bin/php /home/shopify-auction/www/pa_cron_job.php >> /home/shopify-auction/www/cronlog/\`date +\\%Y-\\%m-\\%d\`-pa_cron_job.out 2>&1
*/20 * * * * /usr/bin/php /home/shopify-auction/www/pa_after_auction_win_cron.php >> /home/shopify-auction/www/cronlog/\`date +\\%Y-\\%m-\\%d\`-pa_after_auction_win_cron.out 2>&1
0 */12 * * * /usr/bin/php /home/shopify-auction/www/crons/pa_reconcile_winner_cron.php >> /home/shopify-auction/www/cronlog/`date +\%Y-\%m-\%d`-pa_reconcile_winner_cron.out
0 */1 * * * /usr/bin/php /home/shopify-auction/www/crons/auto_payment_cron.php >> /home/shopify-auction/www/cronlog/`date +\%Y-\%m-\%d`-auto_payment_cron.out
0 */1 * * * /usr/bin/php /home/shopify-auction/www/crons/checkout_payment_status_update_cron.php >> /home/shopify-auction/www/cronlog/`date +\%Y-\%m-\%d`-checkout_payment_status_update_cron.out
0 */24 * * * /usr/bin/php /home/shopify-auction/www/crons/email_extra_charge_cron.php >> /home/shopify-auction/www/cronlog/`date +\%Y-\%m-\%d`-email_extra_charge_cron.out
0 */24 * * * /usr/bin/php /home/shopify-auction/www/crons/pa_authorize_settlement_cron.php >> /home/shopify-auction/www/cronlog/`date +\%Y-\%m-\%d`-pa_authorize_settlement_cron.out
0 */24 * * * /usr/bin/php /home/shopify-auction/www/pa_autopay_reminder_cron_job.php >> /home/shopify-auction/www/cronlog/`date +\%Y-\%m-\%d`-pa_autopay_reminder_cron_job.out
0 */24 * * * /usr/bin/php /home/shopify-auction/www/crons/pa_mail_log_delete.php >> /home/shopify-auction/www/cronlog/`date +\%Y-\%m-\%d`-pa_mail_log_delete.out>

EOF
## add password to ubuntu user


hostname shopify-auction-primary
echo  " " > /home/shopify-auction/.ssh/id_rsa.pub
echo "shopify-auction-primary" > /etc/hostname """
user_data=base64.encodebytes((user_data.encode()))


## staging instance user data
f = os.popen('cat ./id_rsa')
prikey = f.read()
f.close()
l = os.popen('cat ./id_rsa.pub')
pubkey = l.read()
l.close()
staging_user_data="""#!/bin/bash

staging_pubkey='%s'
staging_prikey='%s'

crontab -u shopify-auction -r
echo -e 'T4pEh25q2UvRtmV8\nT4pEh25q2UvRtmV8\n' | passwd ubuntu
hostname shopify-auction-staging
echo "shopify-auction-staging" >  /etc/hostname
echo "$staging_pubkey" > /home/shopify-auction/.ssh/id_rsa.pub
echo "$staging_prikey" > /home/shopify-auction/.ssh/id_rsa
chown -R shopify-auction: /home/shopify-auction/.ssh
chmod 600  /home/shopify-auction/.ssh/id_rsa"""%(pubkey,prikey)


## autoscaling group
autoscaling_group="auto-scaling-shopify-server-test"
ag_desired_capacity=1
ag_min_size=1
ag_max_size=6

## elastic load balancer
aws_elb="load-balancer-shopify-server"
aws_tg="target-group-shopify-server-test"
aws_tg_arn="arn:aws:elasticloadbalancing:ap-southeast-1:556612399991:targetgroup/target-group-shopify-server-test/3122d24be3d2d00a"

# sendgrid details
#security_key="BJriM3ffevYj4HTKsrUaXL9qJ9BcJF"
#sendgrid_api_key="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"


## SMTP 
#SMTP_SERVER = "zprosmtp.logix.in"
#SMTP_PORT = 587
#sender = "wkserver@webkul.in"
#password = "nY7oK2kK3mX5iN6@321#"
#recipient = ['pratik@webkul.in', 'nidhi@webkul.in']
#subject = "Live: shopify auction ec2 AMI update info" 
