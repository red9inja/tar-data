import boto3
from config import *
def main():
    try:
        var = datetime.now().strftime("%y-%m-%d-%H-%M")
        session = boto3.Session(region_name=aws_region)
        con = session.client('ec2')
        ag = session.client('autoscaling')
        elb = session.client('elbv2')
        
        # Add this line to create an AMI from the primary server
        imageId = create_ami(con, primary_server_ip, var)
        
        # Other existing code continues below...
def create_ami(con, primary_server_ip, var):
    try:
        # Describe instances to find instance ID based on the primary_server_ip
        response = con.describe_instances(
            Filters=[
                {
                    'Name': 'private-ip-address',
                    'Values': [primary_server_ip],
                }
            ]
        )

        if not response['Reservations']:
            raise Exception(f"No instance found with private IP {primary_server_ip}")

        instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']

        # Create AMI with the specified name
        ami_name = f"{ami_prefix}-{var}"
        response = con.create_image(
            InstanceId=instance_id,
            Name=ami_name,
            NoReboot=False  # Set to False if reboot is needed
        )

        imageId = response['ImageId']
        waiter_image = con.get_waiter('image_available')
        waiter_image.wait(ImageIds=[imageId])
        logger.info(f"AMI created: {imageId}")

        return imageId

    except Exception as e:
        error_message = f"Error creating AMI from instance {instance_id}: {str(e)}"
        print(Fore.RED + Back.GREEN + error_message + Style.RESET_ALL)
        logger.error(error_message)
        mailer(error_message)
        sys.exit(0)
