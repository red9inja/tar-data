server_configurations = [
    {
        'ip': 13.54.215.113,
        'old_tag': old-shopify-auction-server,
        'new_tag': shopify-server-test-primary,
        'allocation_id': eipalloc-06f47a990c7af0a30
#        'user_data': primary_user_data
    },
    {
        'ip': 54.79.31.237,
        'old_tag': old-shopify-auction-server,
        'new_tag': shopify-server-test-secondry,
        'allocation_id': eipalloc-09eeddd6c501dc82c
#        'user_data': secondary_user_data
    }
]
