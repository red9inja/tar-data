#!/usr/bin/python

import smtplib
import email.utils
from email import encoders
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
#from email.MIMEText import MIMEText
from email.mime.text import MIMEText

import boto3
import sys
import time
from datetime import datetime
from config import *
from ip_add import *
from ip_remove import *
#from jun5.py import *
from colorama import Fore, Back, Style
import logging
logging.basicConfig(filename="access.log",
                    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s',
                    datefmt="%Y-%m-%d %H:%M:%S",
                    filemode='w')
logger=logging.getLogger()
logger.setLevel(logging.INFO)
def main():
    var=datetime.now().strftime("%y-%m-%d-%H-%M")
    session = boto3.Session(region_name=aws_region)
    con = session.client('ec2')
    ag = session.client('autoscaling')
    elb = session.client('elbv2')
    waiter_image = con.get_waiter('image_available')
    waiter_instance_stop = con.get_waiter('instance_stopped')
    waiter_instance_start = con.get_waiter('instance_running')
    waiter_target_in_service = elb.get_waiter('target_in_service')
    waiter_target_deregistered = elb.get_waiter('target_deregistered')
    
    try:
        start_time = datetime.now()
        logger.info("<-------- Initiating update -------->")
        response = con.describe_launch_template_versions(LaunchTemplateName=launch_configuration)
        for version in response['LaunchTemplateVersions']:
            oldimage = version['LaunchTemplateData']['ImageId']
            print (oldimage)
        logger.info("Current AMI in launch configuration: %s" %(oldimage))
        logger.info("Checking availability of primary server")
#        check_primary(con,oldimage)
        #fetch remove instance ids
        logger.info("Fetching instance ids to removed")
        remove_instance_ids = get_instance_ids_in_target_group(aws_tg_arn)
        logger.info("Fetched Instance Ids to be removed : %s" %remove_instance_ids)

        logger.info("Creating ec2 AMI from primary instance: %s" %(primary_aws_name_tag))
        imageId=create_ami(con, ag, var, oldimage)
        logger.info("Ec2 AMI created: %s" %(imageId))
        logger.info("Fetching number of instances under load balancer")
        instance_count=elb_instance_count(con, elb, ag, aws_tg_arn)
        logger.info("Number of instances in load balancer: %s" %(instance_count))
        logger.info("Launching %s intermediate instance(s) from image id: %s" %(instance_count,imageId))
        instances=launch_tmp_instance(con, imageId, instance_count)
        logger.info("Intermediate instance(s) ID(s): %s" %(instances))
        time.sleep(120)
        used_tmp_instance_count = 0
        for server_details in server_configurations:
            logger.info(f"Preparing Intermediate instance as a server: {server_details}")
            update_server(con, elb, instances[used_tmp_instance_count], server_details['ip'], server_details['old_tag'], server_details['new_tag'], server_details['allocation_id'], server_details['user_data'])
            used_tmp_instance_count += 1


#        logger.info("Preparing one Intermediate instance as a Primary server")
#        update_primaryServer(con, elb, instances)
#        logger.info("Preparing another one Intermediate instance as a Secondry server")
#        update_secondryServer(con, elb, instances)
#        logger.info("Primary Server is ready")
#        logger.info("Secondry Server is ready")
        logger.info("Updating launch configuration with new AMI")
        update_launchconfiguration(con, ag, imageId, var)
        logger.info("Attaching Intermediate Instances to loadbalancer")
        update_loadbalancer(con, ag, elb, instances)
        logger.info("Updating autoscaling group")
        update_autoscalinggroup(con, ag, imageId, instances)
        logger.info("Removing old primary server")
        remove_old_primary_server(con, instances)
        logger.info("Old primary server removed")
#        logger.info("Removing old secondry server")
#        remove_old_secondry_server(con, instances)
#        logger.info("Old secondy server removed")
        #fetch add instance data
        logger.info("Fetching instance ids/ips to added")
        add_instance_data = get_instance_data_in_target_group()
        logger.info("Fetched Instance Data to be Added : %s" %add_instance_data)


        #Update Added instances database entry with API
        logger.info("Calling add Database entry API for added instances")
        update_database_add_entry(add_instance_data)

        #Update Remove instance database entry with API
        logger.info("Calling remove Database entry API for removed instances")
        update_database_remove_entry(remove_instance_ids)

        logger.info("Triggering ec2 AMI update notification")
        time_elapsed = datetime.now() - start_time
        print(Fore.RED + Back.GREEN +  'Time elapsed (hh:mm:ss.ms) {}'.format(time_elapsed) + Style.RESET_ALL)
        logger.info('Time elapsed (hh:mm:ss.ms): {}'.format(time_elapsed))
        mail_message="Server Update Successful. ec2 AMI" + " " + imageId + " " + " has been updated on launch configuration."
        mailer(mail_message)
        logger.info("<-------- Update completed -------->")

    except (Exception, e1):
        error1 = "main Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)    



# checking if any server is present for the ami above and it shoul be in running state
def check_primary(con,oldimage):
    try:
        response = con.describe_instances(
        Filters = [
                {
                    'Name': 'tag:Name',
                    'Values': [primary_aws_name_tag]
                },
                {
                    'Name': 'image-id',
                    'Values': [oldimage]

                },
                {
                    'Name': 'ip-address',
                    'Values': [primary_server_ip]

                },
                {
                    'Name': 'instance-state-name',
                    'Values': ['running']
                }
            ]
        )
        instances = response['Reservations']
        print (instances)
        if instances == []:
            raise Exception("primary Instance not present for image id %s. Please create a primary Instance." %(oldimage))
        elif instances != []:
            logger.info("primary instance present for Image id: %s." %(oldimage))
    except (Exception, e1):
        error1 = "Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)        
# checking if any server is present then creating ami out of it

def create_ami(con, ag, var, oldimage):
    try:
        response = con.describe_instances(
            Filters = [
                {
                    'Name': 'tag:Name',
                    'Values': [primary_aws_name_tag]
                },
                {
                    'Name': 'instance-state-name',
                    'Values': ['running']
                },
                {
                    'Name': 'ip-address',
                    'Values': [primary_server_ip]

                }

            ]
        )
        instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']
        print(instance_id)
        logger.info("creating image of primary instance %s" %(instance_id))

        response = con.create_image(
            InstanceId = instance_id,
            Name = ami_prefix+var,
            NoReboot = False
        )
        imageId = response['ImageId']
        print (imageId)
        logger.info("checking Image status of Imageid: "+imageId)
        waiter_image = con.get_waiter('image_available')
        waiter_image.wait(ImageIds = [imageId])
        logger.info("Image Available Imageid: "+imageId)
#        logger.info("terminating staging Instance %s" %(instance_id))  ##terminate later
#        response = con.terminate_instances(
#            InstanceIds = [instance_id]
#        )
        return (imageId)
    except (Exception, e1):
        error1 = "create_ami Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)
def elb_instance_count(con, elb, ag, aws_tg_arn):
    try:
        response = elb.describe_target_health(TargetGroupArn=aws_tg_arn)
        instance_count = len(response['TargetHealthDescriptions'])
        return (instance_count)
    except (Exception, e1):
        error1 = "elb_instance_count Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)
def launch_tmp_instance(con, imageId, instance_count):
    try:
        response = con.run_instances(
            ImageId = imageId,
            SecurityGroupIds = [
                aws_security_group
            ],
            InstanceType = aws_instance_type,
            SubnetId = aws_subnet,
            KeyName = aws_key,
            MaxCount = instance_count,
            MinCount = instance_count,
            UserData = user_data.decode(),
            TagSpecifications=[
                {
                    'ResourceType': 'instance',
                    'Tags': [
                        {
                            'Key': 'Name',
                            'Value': aws_name_tag
                        },
                    ]
                }
            ]

        )
        instances = [instance['InstanceId'] for instance in response['Instances']]
        #print (instances)
        return (instances)
    except (Exception, e1):
        error1 = "launch_tmp_instance Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)    

def update_server(con, elb, instances, server_ip, old_tag, new_tag, allocation_id, user_data):
    try:
        response = con.describe_instances(
            Filters=[
                {
                    'Name': 'ip-address',
                    'Values': [server_ip]
                },
            ],
        )
        instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']
        print(instance_id)
        response = con.create_tags(
            Resources=[instance_id],
            Tags=[
                {
                    'Key': 'Name',
                    'Value': old_tag
                },
            ]
        )
        first_instance = instances
        print(first_instance)
        logger.info(f"Stopping new server {new_tag} before updating crons")
        response = con.stop_instances(
            InstanceIds=[first_instance]
        )
        waiter_instance_stop = con.get_waiter('instance_stopped')
        logger.info("Waiting for the instance to be reached in stopped state")
        waiter_instance_stop.wait(InstanceIds=[first_instance])
        logger.info(f"Updating crons on new server {new_tag}")
        con.modify_instance_attribute(
            InstanceId=first_instance,
            UserData={
                'Value': user_data
            }
        )
        logger.info(f"Starting new server {new_tag}")
        con.associate_address(
            AllocationId=allocation_id,
            InstanceId=first_instance,
            AllowReassociation=True
        )
        con.start_instances(InstanceIds=[first_instance])
        waiter_instance_start = con.get_waiter('instance_running')
        waiter_instance_start.wait(InstanceIds=[first_instance])
        logger.info(f"Tagging instance {first_instance} as {new_tag}")

        con.create_tags(
            Resources=[first_instance],
            Tags=[
                {
                    'Key': 'Name',
                    'Value': new_tag
                },
            ]
        )
    except Exception as e1:
        error1 = f"Error1: {str(e1)}"
        print(Fore.RED + Back.GREEN + error1 + Style.RESET_ALL)
        print(Fore.RED + Back.GREEN + f"Reverting any changes associated with server {new_tag}" + Style.RESET_ALL)
        response = con.describe_instances(
            Filters=[
                {
                    'Name': 'ip-address',
                    'Values': [server_ip]
                },
            ],
        )
        instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']
        logger.info(f"Re-tagging {instance_id} as {new_tag}")

        con.create_tags(
            Resources=[instance_id],
            Tags=[
                {
                    'Key': 'Name',
                    'Value': new_tag
                },
            ]
        )
        sys.exit(0)

def update_launchconfiguration(con, ag, imageId, var):
    try:
        response = con.create_launch_template(
            LaunchTemplateName = var+launch_configuration,
            LaunchTemplateData = {
                'ImageId': imageId,
                'KeyName': aws_key,
                'SecurityGroupIds': [aws_security_group],
                #   'NetworkInterfaces': [{
                #       'AssociatePublicIpAddress': True
                #      }],
                'InstanceType': aws_instance_type,
                'UserData': user_data.decode()
            }
        )       
    
        response = ag.update_auto_scaling_group(
            AutoScalingGroupName = autoscaling_group,
            LaunchTemplate = {
                'LaunchTemplateName': var+launch_configuration,
                'Version': '1'
                }
        )
        response = con.delete_launch_template(
            LaunchTemplateName = launch_configuration

        )
        response = con.create_launch_template(
            LaunchTemplateName = launch_configuration,
            LaunchTemplateData = {
                'ImageId': imageId,
                'KeyName': aws_key,
                'SecurityGroupIds': [aws_security_group],
            #   'NetworkInterfaces': [{
            #       'AssociatePublicIpAddress': True
            #      }],
                'InstanceType': aws_instance_type,
                'UserData': user_data.decode()


            }
        )
        response = ag.update_auto_scaling_group(
            AutoScalingGroupName = autoscaling_group,
            LaunchTemplate = {
                'LaunchTemplateName': launch_configuration,
                'Version': '1'
                }
        )
        response = con.delete_launch_template(
            LaunchTemplateName = var+launch_configuration

        )
        logger.info("launch configuration updated")        
    except (Exception, e1):
        error1 = "update_launchconfiguration Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        #mailer(error1)
        sys.exit(0) 

def update_loadbalancer(con, ag, elb, instances):
    try:
        response = elb.describe_target_health(
            TargetGroupArn = aws_tg_arn
        )
        instance=[]
        for target in response['TargetHealthDescriptions']:
            instance_id = target['Target']['Id']

            instance.append(instance_id)
            # first_instance = instances[0]

    
        first_instance = instances[0]
        #second_instance = instances[1]
        #print(first_instance)
        #print(instance)

        elb.register_targets(
            TargetGroupArn = aws_tg_arn,
            Targets = [
                {
                'Id': first_instance
                }
                #for new_instances in instances
            ]
        )
        waiter_target_in_service = elb.get_waiter('target_in_service')
        waiter_target_in_service.wait(
            TargetGroupArn = aws_tg_arn,
            Targets = [
                {
                    'Id': first_instance
                }
                #for new_instances in instances
            ]
        )

        ##elb.register_targets(
            ##TargetGroupArn = aws_tg_arn,
            ##Targets = [
                ##{
                ##'Id': second_instance
                ##}
                #for new_instances in instances
            ##]
        ##)
        ##waiter_target_in_service = elb.get_waiter('target_in_service')
        ##waiter_target_in_service.wait(
            ##TargetGroupArn = aws_tg_arn,
            ##Targets = [
                ##{
                    ##'Id': second_instance
                ##}
                #for new_instances in instances
            ##]
        ##)
                 
        print("Traget in service")
        if instance != []:
            elb.deregister_targets(
                TargetGroupArn = aws_tg_arn,
                Targets = [
                {
                'Id': instance_id
                }
                for instance_id in instance

            ]
            )
            waiter_target_deregistered = elb.get_waiter('target_deregistered')
            waiter_target_deregistered.wait(
                TargetGroupArn = aws_tg_arn,
                Targets = [
                {
                    'Id': instance_id
                }
                for instance_id in instance
            ]

            )

            print("dergetr sucessfully")
            con.stop_instances(
                InstanceIds = instance
            )
    #except(Exception, e1):
    except botocore.exceptions.WaiterError as e:
        error1 = "update_loadbalancer Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)        
            


def update_autoscalinggroup(con, ag, imageId, instances):
    try:
        response = ag.describe_auto_scaling_groups(AutoScalingGroupNames=[autoscaling_group])
        instance_ids = []
        for group in response['AutoScalingGroups']:
            for instance in group['Instances']:
                instance_ids.append(instance['InstanceId'])
                if instance_ids:
                    ag.terminate_instance_in_auto_scaling_group(
                        InstanceId = instance_ids[0],
                        #InstanceId = instance_ids[1],
                        ShouldDecrementDesiredCapacity = False
                    )
                    print(f'Terminated instances: {instance_ids}')
                else:
                    print(f'No instances found in Auto Scaling gr')
            
        ag.update_auto_scaling_group(
            AutoScalingGroupName = autoscaling_group,
            MinSize = ag_min_size,
            MaxSize = ag_max_size,
            DesiredCapacity = ag_desired_capacity
        )
        ag.attach_instances(
            AutoScalingGroupName = autoscaling_group,
            InstanceIds = [
                instance_id
            for instance_id in instances[1:]
            ]
        )
        logger.info("autoscaling group updated")
    except (Exception, e1):
        error1 = "update_autoscalinggroup Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)    

def remove_old_primary_server(con, instances):
    try:
        response = con.describe_instances(
            Filters = [
                {
                    'Name': 'tag:Name',
                    'Values': [old_aws_name_tag]
                }
                #{
                #    'Name': 'instance-state-name',
                #    'Values': ['stopped']

                #}
                
            ]
        )
        #print()
        instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']
        logger.info("Allowing connection draining for 60 seconds before stopping %s" %(instance_id))
        time.sleep(60)
        logger.info("Terminating Instance %s" %(instance_id))  ## Add sleep for connection draining
        con.terminate_instances(
            InstanceIds = [
                instance_id
            ]
        )
    except (Exception, e1):
        error1 = "remove_tmp_instance Error1: %s" % str(e1) 
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)


if __name__ == '__main__':
    main()
