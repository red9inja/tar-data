import boto3
import sys
import logging
from config import *

logging.basicConfig(filename="access.log",
                    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s',
                    datefmt="%Y-%m-%d %H:%M:%S",
                    filemode='w')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def main():
    try:
        logger.info("<-------- Initiating update -------->")
        instance_id = get_instance_id_from_ip(primary_server_ip)
        logger.info(f"Primary Server IP: {primary_server_ip}")
        logger.info(f"Primary Server Instance ID: {instance_id}")
        remove_primary_server_from_alb(instance_id)
        logger.info(f"Primary server with IP {primary_server_ip} and Instance ID {instance_id} has been successfully deregistered.")
        logger.info("<-------- Update completed -------->")

    except Exception as e1:
        error1 = f"main Error: {str(e1)}"
        logger.error(error1)
        sys.exit(0)

def get_instance_id_from_ip(ip_address):
    session = boto3.Session(region_name=aws_region)
    ec2 = session.client('ec2')

    # Describe instances and filter by IP address to find the instance ID
    response = ec2.describe_instances(
        Filters=[
            {'Name': 'ip-address', 'Values': [ip_address]}
        ]
    )
    # Extract the instance ID from the response
    reservations = response.get('Reservations')
    if not reservations:
        raise Exception(f"No instances found with IP address {ip_address}")

    instances = reservations[0].get('Instances')
    if not instances:
        raise Exception(f"No instances found with IP address {ip_address}")

    instance_id = instances[0]['InstanceId']
    return instance_id

def remove_primary_server_from_alb(instance_id):
    try:
        session = boto3.Session(region_name=aws_region)
        elb = session.client('elbv2')

        logger.info("Removing primary server from the target group.")
        elb.deregister_targets(
            TargetGroupArn=aws_tg_arn,
            Targets=[{'Id': instance_id}]
        )

        logger.info("Waiting for the instance to be deregistered from the target group.")
        waiter_target_deregistered = elb.get_waiter('target_deregistered')
        waiter_target_deregistered.wait(TargetGroupArn=aws_tg_arn, Targets=[{'Id': instance_id}])

        logger.info("Primary server removed successfully.")
    except Exception as e1:
        error1 = f"remove_primary_server_from_alb Error: {str(e1)}"
        logger.error(error1)
        sys.exit(0)

if __name__ == '__main__':
    main()
