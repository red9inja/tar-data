import boto3
import sys
from colorama import Fore, Back, Style
from config import *

session = boto3.Session(region_name=aws_region)
ec2_client = session.client('ec2')
elb_client = session.client('elbv2')
# Create a Boto3 ELB client
def main():
    try:
        # Get the details of the target group attached to the ELB
        target_group_response = elb_client.describe_target_groups(Names=[aws_tg])
        if not target_group_response['TargetGroups']:
            print(f"No target group found for ELB {aws_elb}")
            exit(1)
        target_group_arn = target_group_response['TargetGroups'][0]['TargetGroupArn']

            # Get a list of registered instances in the target group
        instances_response = elb_client.describe_target_health(TargetGroupArn=target_group_arn)

        if not instances_response['TargetHealthDescriptions']:
            print(f"No instances found in the target group of ELB {aws_elb}")
            exit(1)

# Print the private IP addresses of the instances attached to the target group
        print("IP addresses of instances attached to the ELB:")
        for target_health in instances_response['TargetHealthDescriptions']:
            target = target_health['Target']
            instance_id = target['Id']

    # Use EC2 client to get instance details and IP address
    #ec2_client = boto3.client('ec2', region_name=region_name, aws_access_key_id=aws_access_key, aws_secret_access_key=aws_secret_key)
            instance_response = ec2_client.describe_instances(InstanceIds=[instance_id])

            if instance_response['Reservations']:
                instance = instance_response['Reservations'][0]['Instances'][0]
                public_ip = instance.get('PublicIpAddress', 'N/A')
                print(Fore.RED + Back.GREEN + '{0}: {1} '.format("Instance ID", instance_id) + '{0}: {1}'.format("Public IP", public_ip) + Style.RESET_ALL)
    except Exception as e:
        error_msg = f"Error: {str(e)}"
        print(Fore.RED + Back.GREEN + error_msg + Style.RESET_ALL)
        sys.exit(0)

if __name__ == '__main__':
    main()

