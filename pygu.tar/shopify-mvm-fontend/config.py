#!/usr/bin/python
import base64
import os
## ec2 instances
primary_server_ip="54.66.214.29"
primary_ip_allocation_id="eipalloc-0a82c327ebd18adda"
second_server_ip="54.66.105.211"
second_server_ip_allocation_id="eipalloc-042851c519055fcf7"
third_server_ip="52.62.195.19"
third_server_ip_allocation_id="eipalloc-020abebe6327abc77"
#fourth_server_ip="35.83.49.110"
#fourth_server_ip_allocation_id="eipalloc-0d010da3c0de73993"
primary_aws_name_tag="primary_front_mvm_server"
second_primary_aws_name_tag="second_front_mvm_server"
third_primary_aws_name_tag="third_front_mvm_server"
#fourth_primary_aws_name_tag="fourth_mvm_server"

staging_server_ip="13.54.215.113"
staging_ip_allocation_id="eipalloc-06f47a990c7af0a30"
staging_aws_name_tag="staging_front_mvm_server"
old_aws_name_tag="old-primary-front-shopify-mvm-server"
old_second_aws_name_tag="old-second-front-shopify-mvm-server"
old_third_aws_name_tag="old-third-front-shopify-mvm-server"
#old_fourth_aws_name_tag="old-fourth-shopify-mvm-server"
aws_name_tag="tmp-shopify-front-mvm-server"

## ec2 instance parameters
aws_region="ap-southeast-2"
aws_security_group="sg-0a6551c511685128e"
#aws_security_group_rds="sg-0a6551c511685128e"
aws_instance_type="t2.micro"
aws_subnet="subnet-0608c86ef0aa208e5"
aws_key="sydney"

## ec2 ami
ami_prefix="shopify-mvm-front-Image-"

## launch configuration
launch_configuration="shopify-mvm-front-launch-configuration"
launch_configuration_tag="mvm-front-autoscaled-server"
## autoscaled instance user data

## primary instance user data
primary_mvm_user_data="""Content-Type: multipart/mixed; boundary="//"
MIME-Version: 1.0

--//
Content-Type: text/cloud-config; charset="us-ascii"
MIME-Version: 1.0
Content-Transfer-Encoding: 7bit
Content-Disposition: attachment; filename="cloud-config.txt"

#cloud-config
cloud_final_modules:
- [scripts-user, always]

--//
Content-Type: text/x-shellscript; charset="us-ascii"
MIME-Version: 1.0
Content-Transfer-Encoding: 7bit
Content-Disposition: attachment; filename="userdata.txt"

#!/bin/bash

touch /var/spool/cron/crontabs/shopify-mvmf; chmod 600 /var/spool/cron/crontabs/shopify-mvmf; 
chown root:crontab /var/spool/cron/crontabs/shopify-mvmf
cat <<EOF > /var/spool/cron/crontabs/shopify-mvmf
## add crons below

0 2 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/product_review_mail_cron.php

#paypal mp payment reminder cron
0 */12 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/paypal_mp_payment_reminder_cron.php >> /home/shopify-mvmf/www/cronlog/paypalMpPaymentReminder.out

# deleting 1 month before logs
0 6 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/maillog_delete_cron.php

# soopos product update in every 2 hours
*/10 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/soopos_product_update_cron.php

#cron for MVM webhooks retry
*/25 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/webhook_retry_cron.php

# cron for cancel order payment pending by stripe
*/15 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/stripe_order_cancel_cron.php

# cron to process fulfillment webhook data
*/10 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/webhook_data_update_cron.php

0 */6 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/auto_order_track_cron.php
0 */12 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/order_delivery_payment_cron.php
0 1 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/send_fulfillment_reminder.php

#sync squarespace order fulfillment details from seller store to MVM
0 */1 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/squarespace_order_update_n_order_create_cron.php

0 2 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/seller_feedback_to_customer_cron.php

#send mail to seller when inventory is low
50 11 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/low_inventory_send_email_to_seller.php

EOF
chown shopify-mvmf:crontab /var/spool/cron/crontabs/shopify-mvmf

"""

second_mvm_user_data="""Content-Type: multipart/mixed; boundary="//"
MIME-Version: 1.0

--//
Content-Type: text/cloud-config; charset="us-ascii"
MIME-Version: 1.0
Content-Transfer-Encoding: 7bit
Content-Disposition: attachment; filename="cloud-config.txt"

#cloud-config
cloud_final_modules:
- [scripts-user, always]

--//
Content-Type: text/x-shellscript; charset="us-ascii"
MIME-Version: 1.0
Content-Transfer-Encoding: 7bit
Content-Disposition: attachment; filename="userdata.txt"

#!/bin/bash

touch /var/spool/cron/crontabs/shopify-mvmf; chmod 600 /var/spool/cron/crontabs/shopify-mvmf; 
chown root:crontab /var/spool/cron/crontabs/shopify-mvmf
cat <<EOF > /var/spool/cron/crontabs/shopify-mvmf
#update maintenance status
30 09 18 01 * /usr/bin/php /home/shopify-mvmf/www/cron_request/test_mail_cron.php

# for seller memebership
0 1 * * * /usr/bin/php /home/shopify-mvmf/www/cron_membership.php >> /home/shopify-mvmf/www/cronlog/memberCron.out 2>&1
# new seller membership cron started from 12-Sep-2023 16:00
1 0 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/membership_cron_new.php
#*/25 * * * * /usr/bin/php /home/shopify-mvmf/www/csv_submit_cronjob.php >> /home/shopify-mvmf/www/cronlog/csvCron.out 2>&1

# for auto disable product in multivendor
01 05 * * * /usr/bin/php /home/shopify-mvmf/www/product_auto_disable_crontab_process.php >> /home/shopify-mvmf/www/cronlog/autoDisableCron.out 2>&1

# auto-deliver orders with USPS shipping
1 */6 * * * /usr/bin/php /home/shopify-mvmf/www/usps_tracking_api_cron.php >> /home/shopify-mvmf/www/cronlog/uspsTrackingCron.out 2>&1

# Multivendor Seller-Buyer-Chat crons old
#10 0 * * * /usr/bin/php /home/shopify-mvmf/www/seller_chat_payment_cronjob.php >> /home/shopify-mvmf/www/cronlog/demojob.out 2>&1
#01 0 * * * /usr/bin/php /home/shopify-mvmf/www/merchant_chat_payment_cronjob.php >> /home/shopify-mvmf/www/cronlog/MerchantCron.out 2>&1
#20 0 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/sb_chat_cron.php >> /home/shopify-mvmf/www/cronlog/SbChatCron.out 2>&1

# cron for subscription old
30 0 * * * /usr/bin/php /home/shopify-mvmf/www/ck_cron_subscription_pay.php >> /home/shopify-mvmf/www/cronlog/SubscriptionCron.out 2>&1

# cron for csv batch process
#* */1 * * * /usr/bin/php /home/shopify-mvmf/www/batch_process_cron.php >> /home/shopify-mvmf/www/cronlog/batchcsvcron.out 2>&1
0 3 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/expiry_date_cron.php >> /home/shopify-mvmf/www/cronlog/expiry_date_cron.out 2>&1

#cron for masspay 
0 4 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/cachable_amount_pay_cron.php >> /home/shopify-mvmf/www/cronlog/cachable_amount_pay_cron.out 2>&1


#cron request for expiry
0 23 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/order_expire_and_refund_cron.php >> /home/shopify-mvmf/www/cronlog/order_expire_and_refund_cron.out 2>&1

#cron request for paypal payout
0 18 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/paypal_batch_payout_cron.php >> /home/shopify-mvmf/www/cronlog/paypal_batch_payout_cron.out 2>&1

#cron request for extra email
0 15 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/extra_mail_charges_cron.php >> /home/shopify-mvmf/www/cronlog/extra_mail_charges_cron.php.out 2>&1

#seller vactaion for multivendor app
0 1 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/seller_vacation_cron.php >> /home/shopify-mvmf/www/cronlog/seller_vacation_cron.out 2>&1

#subscription product for multivendor app
0 2 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/subscription_product_billing_cron.php >> /home/shopify-mvmf/www/cronlog/subscription_product_billing_cron.out 2>&1

#formp comment affter use
#*/3 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/active_product_cron.php >> /home/shopify-mvmf/www/cronlog/active_product_cron.out 2>&1

#Track order shipment for bluedart Shipping
0 */5 * * *  /usr/bin/php /home/shopify-mvmf/www/cron_request/order_track2_cron.php >> /home/shopify-mvmf/www/cronlog/trackOrder2.out 2>&1

#ecomm
0 20 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/ecom_manifest_create_cron.php

#cron to enable global products
10 */4 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/enable_global_product_cron.php

#cron to send product update webhook data to worker
*/10 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/product_update_cron.php

#cron for updating shopify seller store product webhook from connector product update table 
*/7 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/seller_app_product_update_new_cron.php


#cron for rbbitmqserver closed
*/2 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/rabbit_data_buffer_cron.php

# cron for auto order sync to MVM
#0 1 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/order_sync_cron.php

# send mail to admin regarding unprocessed or unsynced connector orders
0 */4 * * *  /usr/bin/php /home/shopify-mvmf/www/cron_request/connector_order_sync_cron.php

# send mvm webhook order update data to worker
*/10 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/api_webhook_trigger_order_update_cron.php

#run cron everyday for sponsor product feature app
0 1 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/sponsored_product_cron.php

#run cron once in a month to generate monthly app invoice for the stores
5 3 1 * * /usr/bin/php /home/shopify-mvmf/www/cron_request/payment_monthly_invoice_cron.php

#cron to check all the products disabled in a day and send mail with attachment to the admin
05 23 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/disabled_product_csv_cron.php

#cron to process shopify connector data
*/10 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/connector_webhook_data_update_cron.php

#multivendor backup cron running every hour
0 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/multivendor_backup_instance_cron.php

EOF
chown shopify-mvmf:crontab /var/spool/cron/crontabs/shopify-mvmf

"""

third_mvm_user_data="""Content-Type: multipart/mixed; boundary="//"
MIME-Version: 1.0

--//
Content-Type: text/cloud-config; charset="us-ascii"
MIME-Version: 1.0
Content-Transfer-Encoding: 7bit
Content-Disposition: attachment; filename="cloud-config.txt"

#cloud-config
cloud_final_modules:
- [scripts-user, always]

--//
Content-Type: text/x-shellscript; charset="us-ascii"
MIME-Version: 1.0
Content-Transfer-Encoding: 7bit
Content-Disposition: attachment; filename="userdata.txt"

#!/bin/bash

touch /var/spool/cron/crontabs/shopify-mvmf; chmod 600 /var/spool/cron/crontabs/shopify-mvmf; 
chown root:crontab /var/spool/cron/crontabs/shopify-mvmf
cat <<EOF > /var/spool/cron/crontabs/shopify-mvmf

#MVM Canada Post Pickup Request status update
0 */6 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/canadapost_pickup_create_cron.php >> /home/shopify-mvmf/www/cronlog/pickupRequestCP.out 1>&1

#for updating global product order requests status
0 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/decline_global_product_order_request_cron.php >> /home/shopify-mvmf/www/cronlog/orderRequest.out 2>&1

#Track order shipment for Canada Post Shipping
0 */6 * * *  /usr/bin/php /home/shopify-mvmf/www/cron_request/order_track_cron.php >> /home/shopify-mvmf/www/cronlog/trackOrder.out 2>&1

#usage charge for additional digital storage
1 1 * * *  /usr/bin/php /home/shopify-mvmf/www/cron_request/extra_storage_charges.php >> /home/shopify-mvmf/www/cronlog/digitalStorageCharge.out 2>&1

#stripe payment reminder cron
0 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/stripe_payment_reminder_cron.php >> /home/shopify-mvmf/www/cronlog/stripePaymentReminder.out

# check if partner friendly store has completed its trial
30 0 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/partner_friendly_cron.php

# Yearly plan usage charge which will deduct every year
20 0 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/payment_plan_yearly_cron.php

# if app is in trial period, then this will deduct yearly plan price after trial days are over
15 0 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/payment_plan_trial_cron.php

# this will run to update the queued products received from seller woocommerce store into the MVM
*/9 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/woocommerce_product_update_cron.php

# automated bulk invoice 
1 2 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/bulk_invoice_cron.php

#Track order shipment for only one shop woodentwist
0 */4 * * *  /usr/bin/php /home/shopify-mvmf/www/cron_request/order_track3_cron.php >> /home/shopify-mvmf/www/cronlog/trackOrder3.out 2>&1

# sync product inventory from seller stores for particular shop every 6 hours
#commenting this because we do this through other cron shopify connector through modelConnectorprodutUpdate and woocommerce through woo_product_update_worker
#0 */6 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/connector_product_sync_cron.php

# sync product inventory from seller prestashop store every 6 hours
0 */6 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/prestashop_product_sync_cron.php

#this cron changes is_processing value from 1 to 0 after 12 hours and delete after 36 hours from connector product table 
#0 */12 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/connector_product_cron.php

# this will send the bigcommerce products to the processing worker every hour
*/10 * * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/bigcommerce_product_update_cron.php

#detect unsynced connector orders and notify the admin about them
#0 */6 * * * /usr/bin/php /home/shopify-mvmf/www/cron_request/connector_order_sync_cron.php

EOF
chown shopify-mvmf:crontab /var/spool/cron/crontabs/shopify-mvmf

"""

## autoscaled instance user data
user_data="""#!/bin/bash
crontab -u shopify-mvmf -r
"""
#user_data=base64.encodebytes((user_data.encode()))
user_data_launch_template="""#!/bin/bash
crontab -u shopify-mvmf -r
"""

user_data_launch_template=base64.encodebytes((user_data_launch_template.encode()))






## autoscaling group
autoscaling_group="shopify-mvm-front"
ag_desired_capacity=1
ag_min_size=1
ag_max_size=6

## elastic load balancer
aws_elb="shopify-mvm-frontend"
aws_tg="shopify-mvm-frontend-http"
#aws_tg_http="shopify-mvm-frontend-http"
#aws_tg_arn="arn:aws:elasticloadbalancing:ap-southeast-1:276307182872:targetgroup/shopify-mvm-frontend-https/2bffb49a76ec0a33"
#aws_tg_arn_80="arn:aws:elasticloadbalancing:ap-southeast-1:276307182872:targetgroup/shopify-mvm-frontend-http/94a064a7b80b5a7c"
aws_tg_arn="arn:aws:elasticloadbalancing:ap-southeast-2:556612399991:targetgroup/shopify-mvm-frontend-http/7f22c01917b3ff9e"
tag_key="Name"
tag_value="tmp-shopify-front-mvm-server"

##sendgrid details
##security_key="BJriM3ffevYj4HTKsrUaXL9qJ9BcJF"
##sendgrid_api_key="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"


## SMTP 
##SMTP_SERVER = "zprosmtp.logix.in"
##SMTP_PORT = 587
##sender = "wkserver@webkul.in"
##password = "nY7oK2kK3mX5iN6@321#"
##recipient = ['pratik@webkul.in', 'vishwanathacharya.cloud336@webkul.in']
##subject = "Live: shopify mvm-frontend ec2 AMI update info" 

