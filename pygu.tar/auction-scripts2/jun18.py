import boto3

# Import configuration from config.py
from config import aws_region, primary_server_ip, ami_prefix
def create_ami(primary_server_ip, ami_name):
    ec2_client = boto3.client('ec2', region_name=aws_region)

    # Describe instances to find instance ID based on the primary_server_ip
    response = ec2_client.describe_instances(
        Filters=[
            {
                'Name': 'private-ip-address',
                'Values': [primary_server_ip],
            }
        ]
    )

    if not response['Reservations']:
        raise Exception(f"No instance found with private IP {primary_server_ip}")

    instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']

    # Create AMI with the specified name
    timestamp = datetime.datetime.utcnow().strftime('%Y%m%d%H%M%S')
    ami_name = f"{ami_prefix}-{timestamp}"
    
    response = ec2_client.create_image(
        InstanceId=instance_id,
        Name=ami_name,
        NoReboot=True  # Optional: Set to False if reboot is needed
    )

    return response['ImageId']

def main():
    try:
        # Create a timestamped AMI name
        ami_name = f"{ami_prefix}-primary-{time.strftime('%Y%m%d%H%M%S')}"

        # Step 1: Create an AMI from the primary server
        ami_id = create_ami(primary_server_ip, ami_name)
        print(f"Created AMI with ID: {ami_id}")

    except Exception as e:
        print(f"Error creating AMI: {str(e)}")

if __name__ == '__main__':
    main()
