#!/usr/bin/python

import smtplib
import email.utils
from email import encoders
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
#from email.MIMEText import MIMEText
from email.mime.text import MIMEText

import boto3
import sys
import time
from datetime import datetime
from config import *
from ip_add import *
from ip_remove import *

from colorama import Fore, Back, Style
import logging
logging.basicConfig(filename="access.log",
                    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s',
                    datefmt="%Y-%m-%d %H:%M:%S",
                    filemode='w')
logger=logging.getLogger()
logger.setLevel(logging.INFO)
def main():
    var=datetime.now().strftime("%y-%m-%d-%H-%M")
    session = boto3.Session(region_name=aws_region)
    con = session.client('ec2')
    ag = session.client('autoscaling')
    elb = session.client('elbv2')
    waiter_image = con.get_waiter('image_available')
    waiter_instance_stop = con.get_waiter('instance_stopped')
    waiter_instance_start = con.get_waiter('instance_running')
    waiter_target_in_service = elb.get_waiter('target_in_service')
    waiter_target_deregistered = elb.get_waiter('target_deregistered')
    
    try:
        start_time = datetime.now()
        logger.info("<-------- Initiating update -------->")
        response = con.describe_launch_template_versions(LaunchTemplateName=launch_configuration)
        for version in response['LaunchTemplateVersions']:
            oldimage = version['LaunchTemplateData']['ImageId']
            print (oldimage)
        logger.info("Current AMI in launch configuration: %s" %(oldimage))
        logger.info("Checking availability of primary server")
#        check_primary(con,oldimage)
        #fetch remove instance ids
        logger.info("Fetching instance ids to removed")
        remove_instance_ids = get_instance_ids_in_target_group(aws_tg_arn)
        logger.info("Fetched Instance Ids to be removed : %s" %remove_instance_ids)

        logger.info("Creating ec2 AMI from primary instance: %s" %(primary_aws_name_tag))
        imageId=create_ami(con, ag, var, oldimage)
        logger.info("Ec2 AMI created: %s" %(imageId))
        logger.info("Fetching number of instances under load balancer")
        instance_count=elb_instance_count(con, elb, ag, aws_tg_arn)
        logger.info("Number of instances in load balancer: %s" %(instance_count))
        logger.info("Launching %s intermediate instance(s) from image id: %s" %(instance_count,imageId))
        instances=launch_tmp_instance(con, imageId, instance_count)
        logger.info("Intermediate instance(s) ID(s): %s" %(instances))
        time.sleep(120)
        logger.info("Preparing one Intermediate instance as a Primary server")
        update_primaryServer(con, elb, instances)
        logger.info("Preparing another one Intermediate instance as a Secondry server")
        update_secondryServer(con, elb, instances)
        logger.info("Primary Server is ready")
        logger.info("Secondry Server is ready")
        logger.info("Updating launch configuration with new AMI")
        update_launchconfiguration(con, ag, imageId, var)
        logger.info("Attaching Intermediate Instances to loadbalancer")
        update_loadbalancer(con, ag, elb, instances)
        logger.info("Updating autoscaling group")
        update_autoscalinggroup(con, ag, imageId, instances)
        logger.info("Removing old primary server")
        remove_old_primary_server(con, instances)
        logger.info("Old primary server removed")
        logger.info("Removing old secondry server")
        remove_old_secondry_server(con, instances)
        logger.info("Old secondy server removed")
        #fetch add instance data
        logger.info("Fetching instance ids/ips to added")
        add_instance_data = get_instance_data_in_target_group()
        logger.info("Fetched Instance Data to be Added : %s" %add_instance_data)


        #Update Added instances database entry with API
        logger.info("Calling add Database entry API for added instances")
        update_database_add_entry(add_instance_data)

        #Update Remove instance database entry with API
        logger.info("Calling remove Database entry API for removed instances")
        update_database_remove_entry(remove_instance_ids)

        logger.info("Triggering ec2 AMI update notification")
        time_elapsed = datetime.now() - start_time
        print(Fore.RED + Back.GREEN +  'Time elapsed (hh:mm:ss.ms) {}'.format(time_elapsed) + Style.RESET_ALL)
        logger.info('Time elapsed (hh:mm:ss.ms): {}'.format(time_elapsed))
        mail_message="Server Update Successful. ec2 AMI" + " " + imageId + " " + " has been updated on launch configuration."
        mailer(mail_message)
        logger.info("<-------- Update completed -------->")

    except (Exception, e1):
        error1 = "main Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)    



# checking if any server is present for the ami above and it shoul be in running state
def check_primary(con,oldimage):
    try:
        response = con.describe_instances(
        Filters = [
                {
                    'Name': 'tag:Name',
                    'Values': [primary_aws_name_tag]
                },
                {
                    'Name': 'image-id',
                    'Values': [oldimage]

                },
                {
                    'Name': 'ip-address',
                    'Values': [primary_server_ip]

                },
                {
                    'Name': 'instance-state-name',
                    'Values': ['running']
                }
            ]
        )
        instances = response['Reservations']
        print (instances)
        if instances == []:
            raise Exception("primary Instance not present for image id %s. Please create a primary Instance." %(oldimage))
        elif instances != []:
            logger.info("primary instance present for Image id: %s." %(oldimage))
    except (Exception, e1):
        error1 = "Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)        
# checking if any server is present then creating ami out of it

def create_ami(con, ag, var, oldimage):
    try:
        response = con.describe_instances(
            Filters = [
                {
                    'Name': 'tag:Name',
                    'Values': [primary_aws_name_tag]
                },
                {
                    'Name': 'instance-state-name',
                    'Values': ['running']
                },
                {
                    'Name': 'ip-address',
                    'Values': [primary_server_ip]

                }

            ]
        )
        instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']
        print(instance_id)
        logger.info("creating image of primary instance %s" %(instance_id))

        response = con.create_image(
            InstanceId = instance_id,
            Name = ami_prefix+var,
            NoReboot = False
        )
        imageId = response['ImageId']
        print (imageId)
        logger.info("checking Image status of Imageid: "+imageId)
        waiter_image = con.get_waiter('image_available')
        waiter_image.wait(ImageIds = [imageId])
        logger.info("Image Available Imageid: "+imageId)
#        logger.info("terminating staging Instance %s" %(instance_id))  ##terminate later
#        response = con.terminate_instances(
#            InstanceIds = [instance_id]
#        )
        return (imageId)
    except (Exception, e1):
        error1 = "create_ami Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)
def elb_instance_count(con, elb, ag, aws_tg_arn):
    try:
        response = elb.describe_target_health(TargetGroupArn=aws_tg_arn)
        instance_count = len(response['TargetHealthDescriptions'])
        return (instance_count)
    except (Exception, e1):
        error1 = "elb_instance_count Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)
def launch_tmp_instance(con, imageId, instance_count):
    try:
        response = con.run_instances(
            ImageId = imageId,
            SecurityGroupIds = [
                aws_security_group
            ],
            InstanceType = aws_instance_type,
            SubnetId = aws_subnet,
            KeyName = aws_key,
            MaxCount = instance_count,
            MinCount = instance_count,
            UserData = user_data.decode(),
            TagSpecifications=[
                {
                    'ResourceType': 'instance',
                    'Tags': [
                        {
                            'Key': 'Name',
                            'Value': aws_name_tag
                        },
                    ]
                }
            ]

        )
        instances = [instance['InstanceId'] for instance in response['Instances']]
        #print (instances)
        return (instances)
    except (Exception, e1):
        error1 = "launch_tmp_instance Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1)
        sys.exit(0)    
def update_primaryServer(con, elb, instances):
    try:
        response = con.describe_instances(

            Filters=[
            {
                'Name': 'ip-address',
                'Values': [primary_server_ip]

            },
        ],
        )
       # print (response)
        instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']
        print (instance_id)
        response = con.create_tags(
            Resources=[
                instance_id
                ],
            Tags=[
                {
                    'Key': 'Name',
                    'Value': old_aws_name_tag
                },
            ]
        )
        logger.info(f"Instances Created from images: {instances}")
        first_instances = instances[0]
        print(first_instances)
        logger.info("Stopping new primary server before updating crons")
        response = con.stop_instances(
            InstanceIds = [
                first_instances
            ]
        )
        waiter_instance_stop = con.get_waiter('instance_stopped')
        logger.info("waiting for the instance to be reached in stopeed state")
        waiter_instance_stop.wait(InstanceIds = [first_instances])
        logger.info("Updating crons on new primary server")
        con.modify_instance_attribute(
            InstanceId = first_instances,
            UserData ={
                'Value': primary_user_data
            }
        )
        logger.info("Starting new primary server.")
        con.associate_address(
        AllocationId = primary_ip_allocation_id,
        InstanceId = first_instances,
        AllowReassociation = True
        )
        con.start_instances(InstanceIds = [first_instances])
        waiter_instance_start = con.get_waiter('instance_running')
        waiter_instance_start.wait(InstanceIds = [first_instances])
        logger.info("Tagging instance %s as %s." %(first_instances,primary_aws_name_tag))

        con.create_tags(
            Resources=[
                first_instances
                ],
            Tags=[
                {
                    'Key': 'Name',
                    'Value': primary_aws_name_tag
                },
            ]
        )
        #break
    except (Exception, e1):
        error1 = "Error1: %s" % str(e1)  ##revert changes in primary server
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        print(Fore.RED + Back.GREEN + "Reverting any changes associated with primary server" + Style.RESET_ALL)
        response = con.describe_instances(
            
            Filters=[
            {
                'Name': 'ip-address',
                'Values': [primary_server_ip]

            },
        ],
        )
        instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']
        logger.info("Re-tagging %s as %s" %(instance_id,primary_aws_name_tag))


        con.create_tags(
            Resources=[
                instance_id
                ],
            Tags=[
                {
                    'Key': 'Name',
                    'Value': primary_aws_name_tag
                },
            ]
        )
        #mailer(error1)
        sys.exit(0)
def update_secondryServer(con, elb, instances):
    try:
        response = con.describe_instances(
            Filters=[
                {
                    'Name': 'ip-address',
                    'Values': [secondry_server_ip]
                },
            ],
        )
        instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']
        print(instance_id)
        response = con.create_tags(
            Resources=[
                instance_id
            ],
            Tags=[
                {
                    'Key': 'Name',
                    'Value': old_aws_name_tag
                },
            ]
        )
        # Use the second instance in the list for the secondary server
        logger.info(f"Second temp Instances {instances}")
        second_instances = instances[1]
        print(second_instances)
        logger.info("Stopping new secondary server before updating crons")
        response = con.stop_instances(
            InstanceIds=[
                second_instances
            ]
        )
        waiter_instance_stop = con.get_waiter('instance_stopped')
        logger.info("waiting for the instance to be reached in stopped state")
        waiter_instance_stop.wait(InstanceIds=[second_instances])
        logger.info("Updating crons on new secondary server")
        con.modify_instance_attribute(
            InstanceId=second_instances,
            UserData={
                'Value': primary_user_data  # Ensure this is correct for the secondary server
            }
        )
        logger.info("Starting new secondary server.")
        con.associate_address(
            AllocationId=secondry_ip_allocation_id,
            InstanceId=second_instances,
            AllowReassociation=True
        )
        con.start_instances(InstanceIds=[second_instances])
        waiter_instance_start = con.get_waiter('instance_running')
        waiter_instance_start.wait(InstanceIds=[second_instances])
        logger.info("Tagging instance %s as %s." % (second_instances, secondry_aws_name_tag))

        con.create_tags(
            Resources=[
                second_instances
            ],
            Tags=[
                {
                    'Key': 'Name',
                    'Value': secondry_aws_name_tag
                },
            ]
        )
    except (Exception, e1):
        error1 = "Error1: %s" % str(e1)  ##revert changes in secondary server
        print(Fore.RED + Back.GREEN + error1 + Style.RESET_ALL)
        print(Fore.RED + Back.GREEN + "Reverting any changes associated with secondary server" + Style.RESET_ALL)
        response = con.describe_instances(
            Filters=[
                {
                    'Name': 'ip-address',
                    'Values': [secondry_server_ip]
                },
            ],
        )
        instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']
        logger.info("Re-tagging %s as %s" % (instance_id, secondry_aws_name_tag))

        con.create_tags(
            Resources=[
                instance_id
            ],
            Tags=[
                {
                    'Key': 'Name',
                    'Value': secondry_aws_name_tag
                },
            ]
        )
        sys.exit(0)
