import boto3
import sys
import time
from datetime import datetime
import logging
from config import *

logging.basicConfig(filename="access.log",
                    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s',
                    datefmt="%Y-%m-%d %H:%M:%S",
                    filemode='w')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def main():
    try:
        logger.info("<-------- Initiating update -------->")
        remove_primary_server()
        logger.info("<-------- Update completed -------->")

    except Exception as e1:
        error1 = f"main Error: {str(e1)}"
        logger.error(error1)
        sys.exit(0)    

def remove_primary_server():
    try:
        session = boto3.Session(region_name=aws_region)
        elb = session.client('elbv2')
        con = session.client('ec2')

        response = elb.describe_target_health(TargetGroupArn=aws_tg_arn)
        instance_ids = [target['Target']['Id'] for target in response['TargetHealthDescriptions']]

        if instance_ids:
            logger.info("Removing primary server from the target group.")
            elb.deregister_targets(TargetGroupArn=aws_tg_arn, Targets=[{'Id': instance_ids[0]}])

            logger.info("Waiting for the instance to be deregistered from the target group.")
            waiter_target_deregistered = elb.get_waiter('target_deregistered')
            waiter_target_deregistered.wait(TargetGroupArn=aws_tg_arn, Targets=[{'Id': instance_ids[0]}])

            logger.info("Primary server removed successfully.")
        else:
            logger.info("No instances found in the target group.")
    except Exception as e1:
        error1 = f"remove_primary_server Error: {str(e1)}"
        logger.error(error1)
        sys.exit(0)

if __name__ == '__main__':
    main()
