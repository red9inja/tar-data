import boto3
#import boto.ec2.autoscale
#from boto.ec2.autoscale.launchconfig import LaunchConfiguration
import sys
import time
from datetime import datetime
from config import *
from colorama import Fore, Back, Style
import logging

logging.basicConfig(filename="access.log",
                    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s',
                    datefmt="%Y-%m-%d %H:%M:%S",
                    filemode='w')
logger=logging.getLogger()
logger.setLevel(logging.INFO)
session = boto3.Session(region_name=aws_region)
con = session.client('ec2')
ag = session.client('autoscaling')
waiter = con.get_waiter('instance_running')

logger.info("<------ Initiating Staging Server creation ------>")
logger.info("Retrieving current image id from launch configuration")
response = con.describe_launch_template_versions(LaunchTemplateName=launch_configuration)
for version in response['LaunchTemplateVersions']:
    imageID = version['LaunchTemplateData']['ImageId']
    print (imageID)
response = con.describe_instances(
        Filters = [
                {
                    'Name': 'tag:Name',
                    'Values': [staging_aws_name_tag]
                },
                {
                    'Name': 'image-id',
                    'Values': [imageID]

                },
                {
                    'Name': 'ip-address',
                    'Values': [staging_server_ip]

                }
            ]
        )
#print(reservations) 
#print(response) 
instances = response['Reservations']
print (instances)
if instances == []:
    #logger.info("Retrieving instances with specific tag")
    #response = con.describe_instances(
    #    Filters = [
     #       {
     #           'Name': 'tag:Need',
     #           'Values': ['deletion']
     #       }
            #{
            #'Name': 'instance-state-name',
            #'Values': ['running']
            #}
     #   ]
   # )
    #instances = response['Reservations']
    #for reservation in instances:
    #    for instance in reservation['Instances']:
    #        instance_id = instance['InstanceId']
    #instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']
    #if instance.length > 0:
    #print(instance_id)
   # response = con.terminate_instances(
   #     InstanceIds = [instance_id]
   # )
   # logger.info("Now deleting the previous instance with the deletion tag")
   # logger.info("deleted")
    logger.info("Staging Instance not present for image id %s" %(imageID))
    logger.info("Creating a staging instance from image id %s" %(imageID))
    response = con.run_instances(
        ImageId = imageID,
        SecurityGroupIds = [
            aws_security_group
        ],
        InstanceType = aws_instance_type,
        SubnetId = aws_subnet,
        KeyName = aws_key,
        MaxCount = 1,
        MinCount =1,
        UserData = staging_user_data,
        TagSpecifications=[
            {
                'ResourceType': 'instance',
                'Tags': [
                    {
                        'Key': 'Name',
                        'Value': staging_aws_name_tag
                    },
                    {
                        'Key': 'Need',
                        'Value': 'deletion'
                    },
                ]
            }
        ]

    )
    instance_id = response['Instances'][0]['InstanceId']
    print(instance_id)
    logger.info("Staging instance tagged as %s" %(staging_aws_name_tag))
    logger.info("Waiting for instance to be in running state before assigning elastic IP")
    waiter.wait(
        InstanceIds =[
            instance_id
        ]

    )
    logger.info("Instance is running now")
    logger.info("Assigning Elastic IP to the staging instance")
    response = con.associate_address(
        AllocationId = staging_ip_allocation_id,
        InstanceId = instance_id,
        AllowReassociation = True 
    )
    logger.info("Elastic IP %s has been associated with Staging instance" %(staging_server_ip))
    print(Fore.RED + Back.GREEN + "Staging Server Created." + Style.RESET_ALL)
    logger.info("<------ Staging Server created ------>")
#elif instances != []:
#    logger.info("Staging Instance found for image id %s" %(imageID))
elif instances != []:
    logger.info("Staging Instance found for image id %s" %(imageID))
 #   if existing_instances:
  #  logger.info("Staging Instance found for image id %s", imageID)
    for reservation in instances:
        for instance in reservation['Instances']:
            tags = instance.get('Tags', [])
            name = next((tag['Value'] for tag in tags if tag['Key'] == 'Name'), '(unnamed)')
            if instance['State']['Name'] == 'running':
                logger.info('%s: %s: %s', name, instance['InstanceId'], instance.get('PrivateIpAddress', 'N/A'))
            elif instance['State']['Name'] == 'stopped':
                logger.info('%s: %s', name, instance['InstanceId'])
                logger.info("server is in stopped state")
            else:
                pass
                #else:
                logger.info("No new Staging Server has been created from image id %s. Kindly use an existing Staging Server.", imageID)
                print("NO new Staging Server has been created. Kindly use an existing Staging Server.")



