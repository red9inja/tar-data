import boto3
import requests
from config import *
#aws_tg_arn
def get_instance_ids_in_target_group(aws_tg_arn):
    """
    Get instance IDs of instances registered in the specified target group.
    """
    session = boto3.Session(region_name=aws_region)
    #ec2_client = session.client('ec2')
    client = session.client('elbv2')
    #elb_client = boto3.client('elbv2')
    response = client.describe_target_health(TargetGroupArn=aws_tg_arn)

    instance_ids = []
    for target_health in response['TargetHealthDescriptions']:
        if 'Target' in target_health and 'Id' in target_health['Target']:
            instance_ids.append(target_health['Target']['Id'])
    print("Instance IDs in target group:")
    print(instance_ids)

    return instance_ids


def update_database_remove_entry(instance_ids):
    send_grid_api_key = sendgrid_api_key
    #security_key = security_key
    url = 'https://sp-auction.webkul.com/product-auction-api/send_grid/remove_ips'
    headers = {
        'x-security-key': security_key,
        'Content-Type': 'application/json'
    }

    for instance_id in instance_ids:
        payload = {
            "instance_id": instance_id,
            "api_key": send_grid_api_key,
        }
        print('payload:',payload)
        try:
            response = requests.post(url, json=payload, headers=headers)
            response.raise_for_status()
            print(response)
            print (response.text)
            # return response.text
        except Exception as e:
            print (f"Error: {str(e)}")


if __name__ == "__main__":
    instance_ids = get_instance_ids_in_target_group(aws_tg_arn)
    update_database_remove_entry(instance_ids)
#    target_group_arn = 'arn:aws:elasticloadbalancing:us-east-2:556612399991:targetgroup/dev443/7ee10bb31d56b14e'

#    instance_ids = get_instance_ids_in_target_group(target_group_arn)
 #   print("Instance IDs in target group:")
 #   print(instance_ids)



