import boto3
from config import *

import json
import requests
import os

session = boto3.Session(region_name=aws_region)
ec2_client = session.client('ec2')
elbv2_client = session.client('elbv2')

def get_target_instances(target_group_arn):
    response = elbv2_client.describe_target_health(TargetGroupArn=target_group_arn)
    return [target['Target']['Id'] for target in response['TargetHealthDescriptions']]

def get_instance_info(instance_id):
    response = ec2_client.describe_instances(InstanceIds=[instance_id])
    instance = response['Reservations'][0]['Instances'][0]
    return instance

def filter_instances_by_tag(instances, tag_key, tag_value):
    filtered_instances = []
    filtered_instance_data = {}
    for instance_id in instances:
        instance = get_instance_info(instance_id)
        for tag in instance.get('Tags', []):
            if tag['Key'] == tag_key and tag['Value'] == tag_value:
                filtered_instances.append(instance)
    #return filtered_instances
    for instance in filtered_instances:
        public_ip = instance.get('PublicIpAddress', 'N/A')
        print(f"Instance ID: {instance['InstanceId']}, Public IP: {public_ip}")
        filtered_instance_data[(instance['InstanceId'])] = public_ip
    print(filtered_instance_data)
    return filtered_instance_data




def get_filter_instance_by_tag(aws_tg_arn, tag_key, tag_value):
    """Method returns filtered instance id and IP based tag key/value"""
    target_instances = get_target_instances(aws_tg_arn)
    filtered_instances_data = filter_instances_by_tag(target_instances, tag_key, tag_value)
    return filtered_instances_data




def update_database_add_entry(filetered_instance_data):
    url = 'https://sp-auction.webkul.com/product-auction-api/send_grid/add_ips'
    headers = {
        'x-security-key': security_key,
        'Content-Type': 'application/json'
    }
    for instance_id in filetered_instance_data:
        instance_public_ip = filetered_instance_data[instance_id]

        print("Instance Details->",instance_id,":",instance_public_ip)

        payload = {
            "instance_ip": instance_public_ip,
            "instance_id": instance_id,
            "api_key": sendgrid_api_key,
            "ip_for": "marketplace-front"
        }

        try:
            response = requests.post(url, json=payload, headers=headers)
            response.raise_for_status()
            print(response)
            print (response.text)
            # return response.text
        except Exception as e:
            print(f"Error: {str(e)}")



def update_database_remove_entry(filetered_instance_ids):
    send_grid_api_key = sendgrid_api_key
    #security_key = security_key
    url = 'https://sp-auction.webkul.com/product-auction-api/send_grid/remove_ips'
    headers = {
        'x-security-key': security_key,
        'Content-Type': 'application/json'
    }

    for instance_id in filetered_instance_ids:
        payload = {
            "instance_id": instance_id,
            "api_key": send_grid_api_key,
        }
        print('payload:',payload)
        try:
            response = requests.post(url, json=payload, headers=headers)
            response.raise_for_status()
            print(response)
            print (response.text)
            # return response.text
        except Exception as e:
            print (f"Error: {str(e)}")


def main():

    target_instances = get_target_instances(aws_tg_arn)
    filtered_instances = filter_instances_by_tag(target_instances, tag_key, tag_value)


if __name__ == "__main__":
    main()


