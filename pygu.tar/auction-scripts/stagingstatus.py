import boto3
import sys
import time
from datetime import datetime
from config import *
from colorama import Fore, Back, Style
import logging

session = boto3.Session(region_name=aws_region)
con = session.client('ec2')
#ag = session.client('autoscaling')
#elb = session.client('elbv2')


def main():
    try:
        response = con.describe_launch_template_versions(LaunchTemplateName=launch_configuration)
        for version in response['LaunchTemplateVersions']:
            imageID = version['LaunchTemplateData']['ImageId']
           # print (imageID)
        stateInstance(con, imageID)
        if len(sys.argv) != 3:
           print (Fore.RED + Back.GREEN + "To create new staging instance, run: python createStaging.py" + Style.RESET_ALL)
        elif sys.argv[1] == "start":
           staging_instance_id=sys.argv[2]
           startInstance(con,staging_instance_id)
        else:
            pass
    except (Exception, e1):
        error2 = "Error2: %s" % str(e1)
        print (Fore.RED + Back.GREEN +  error2 + Style.RESET_ALL)
        sys.exit(0)    

def startInstance(con,staging_instance_id):
    print("Starting the instance...")
    try:
        con.start_instances(
            InstanceIds=[
                staging_instance_id
                ]
        )
        print("Instance is getting started.")
    except (Exception, e2):
        error2 = "Error2: %s" % str(e2)
        print (Fore.RED + Back.GREEN +  error2 + Style.RESET_ALL)
        sys.exit(0)
def stateInstance(con, imageID):
    try:
        response=con.describe_instances(
            Filters = [
                {
                    'Name': 'tag:Name',
                    'Values': [staging_aws_name_tag]
                },
                {
                'Name': 'image-id',
                'Values': [imageID]
                },
                {
                'Name': 'ip-address',
                'Values': [staging_server_ip]
                }
            ]
        )

        instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']
        state = response['Reservations'][0]['Instances'][0]['State']['Name']
        public_ip = response['Reservations'][0]['Instances'][0]['PublicIpAddress']

        if state=="running":
            print("Staging Server is present")
            print("Server is in running state")
            print(instance_id,public_ip)
        #[0]['AvailabilityZone']
        elif state=="stopped":
            print("Server is present but it is in stopped condition now")
            print(instance_id)
            print("To start Staging instance, run: python stagingStatus.py start #mention_staging_instance_id")
    except (Exception, e3):
        error2 = "Error2: %s" % str(e3)
        print (Fore.RED + Back.GREEN +  error2 + Style.RESET_ALL)
        sys.exit(0)    


if __name__ == '__main__':
    main()

