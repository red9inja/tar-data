import boto3
import sys
import requests
import os
from colorama import Fore, Back, Style
from config import *

session = boto3.Session(region_name=aws_region)
ec2_client = session.client('ec2')
elb_client = session.client('elbv2')
# Create a Boto3 ELB client
def get_instance_data_in_target_group():
    try:
        # Get the details of the target group attached to the ELB
        target_group_response = elb_client.describe_target_groups(Names=[aws_tg])
        if not target_group_response['TargetGroups']:
            print(f"No target group found for ELB {aws_elb}")
            exit(1)
        target_group_arn = target_group_response['TargetGroups'][0]['TargetGroupArn']

            # Get a list of registered instances in the target group
        instances_response = elb_client.describe_target_health(TargetGroupArn=target_group_arn)

        if not instances_response['TargetHealthDescriptions']:
            print(f"No instances found in the target group of ELB {aws_elb}")
            exit(1)

# Print the private IP addresses of the instances attached to the target group
        print("IP addresses of instances attached to the ELB:")
        instance_data = {}
        for target_health in instances_response['TargetHealthDescriptions']:
            target = target_health['Target']
            instance_id = target['Id']

    # Use EC2 client to get instance details and IP address
    #ec2_client = boto3.client('ec2', region_name=region_name, aws_access_key_id=aws_access_key, aws_secret_access_key=aws_secret_key)
            instance_response = ec2_client.describe_instances(InstanceIds=[instance_id])

            if instance_response['Reservations']:
                instance = instance_response['Reservations'][0]['Instances'][0]
                public_ip = instance.get('PublicIpAddress', 'N/A')
               # sg = SendGridAPIClient(sendgrid_api_key)
               # data = {
               #         "ips": [{"ip": public_ip}]
               #         }
               # response = sg.client.access_settings.whitelist.post(
               # request_body=data
               # )
               # print(response.status_code)
               # print(response.body)
                #print(response.headers)
                #########Store Instance Id & IPs in dict########
                instance_data[instance_id] = public_ip
                print(Fore.RED + Back.GREEN + '{0}: {1} '.format("Instance ID", instance_id) + '{0}: {1}'.format("Public IP", public_ip) + Style.RESET_ALL)
        print("Instance Data:",instance_data)

        return instance_data
    except Exception as e:
        error_msg = f"Error: {str(e)}"
        print(Fore.RED + Back.GREEN + error_msg + Style.RESET_ALL)
        sys.exit(0)




def update_database_add_entry(instance_data):
    url = 'https://sp-auction.webkul.com/product-auction-api/send_grid/add_ips'
    headers = {
        'x-security-key': security_key,
        'Content-Type': 'application/json'
    }
    for instance_id in instance_data:
        instance_public_ip = instance_data[instance_id]

        print("Instance Details->",instance_id,":",instance_public_ip)

        payload = {
            "instance_ip": instance_public_ip,
            "instance_id": instance_id,
            "api_key": sendgrid_api_key,
            "ip_for": "auction"
        }

        try:
            response = requests.post(url, json=payload, headers=headers)
            response.raise_for_status()
            print(response)
            print (response.text)
            # return response.text
        except Exception as e:
            print(f"Error: {str(e)}")

if __name__ == '__main__':
    instance_data = get_instance_data_in_target_group()
    update_database_add_entry(instance_data)

