#!/usr/bin/python
import boto3
import time

# Load configurations from config file
from config import primary_server_ip, primary_ip_allocation_id, primary_aws_name_tag
from config import secondry_server_ip, secondry_ip_allocation_id, secondry_aws_name_tag
from config import aws_region, aws_security_group, aws_instance_type, aws_subnet, aws_key
from config import autoscaling_group, ag_desired_capacity, ag_min_size, ag_max_size
from config import aws_elb, aws_tg, aws_tg_arn

# Initialize Boto3 clients
ec2_client = boto3.client('ec2', region_name=aws_region)
elbv2_client = boto3.client('elbv2', region_name=aws_region)
autoscaling_client = boto3.client('autoscaling', region_name=aws_region)

def create_ami_from_instance(instance_id, name_tag):
    response = ec2_client.create_image(
        InstanceId=instance_id,
        Name=f"{name_tag}-ami",
        NoReboot=True
    )
    image_id = response['ImageId']
    return image_id

def get_target_group_instances(target_group_arn):
    response = elbv2_client.describe_target_health(TargetGroupArn=target_group_arn)
    instances = [target['Target']['Id'] for target in response['TargetHealthDescriptions']]
    return instances

def launch_instance(image_id, count):
    instances = ec2_client.run_instances(
        ImageId=image_id,
        InstanceType=aws_instance_type,
        KeyName=aws_key,
        SecurityGroupIds=[aws_security_group],
        SubnetId=aws_subnet,
        MinCount=count,
        MaxCount=count
    )
    instance_ids = [instance['InstanceId'] for instance in instances['Instances']]
    return instance_ids

def deregister_instances_from_target_group(target_group_arn, instance_ids):
    targets = [{'Id': instance_id} for instance_id in instance_ids]
    elbv2_client.deregister_targets(
        TargetGroupArn=target_group_arn,
        Targets=targets
    )

def register_instances_to_target_group(target_group_arn, instance_ids):
    targets = [{'Id': instance_id} for instance_id in instance_ids]
    elbv2_client.register_targets(
        TargetGroupArn=target_group_arn,
        Targets=targets
    )

def terminate_instances(instance_ids):
    ec2_client.terminate_instances(InstanceIds=instance_ids)

def main():
    # Step 1: Create AMI from the primary server
    primary_instance_id = ec2_client.describe_instances(
        Filters=[
            {'Name': 'tag:Name', 'Values': [primary_aws_name_tag]},
            {'Name': 'private-ip-address', 'Values': [primary_server_ip]}
        ]
    )['Reservations'][0]['Instances'][0]['InstanceId']
    
    ami_id = create_ami_from_instance(primary_instance_id, primary_aws_name_tag)
    
    # Wait for AMI to become available
    waiter = ec2_client.get_waiter('image_available')
    waiter.wait(ImageIds=[ami_id])
    
    # Step 2: Get current instances in the target group
    old_instances = get_target_group_instances(aws_tg_arn)
    instance_count = len(old_instances)
    
    # Step 3: Launch new instances
    new_instance_ids = launch_instance(ami_id, instance_count)
    
    # Wait for instances to be in running state
    waiter = ec2_client.get_waiter('instance_running')
    waiter.wait(InstanceIds=new_instance_ids)
    
    # Step 4: Register new instances to target group
    register_instances_to_target_group(aws_tg_arn, new_instance_ids)
    
    # Step 5: Deregister old instances from target group
    deregister_instances_from_target_group(aws_tg_arn, old_instances)
    
    # Step 6: Terminate old instances
    terminate_instances(old_instances)
    
    print(f"Successfully replaced {instance_count} instances in the target group with new ones.")

if __name__ == "__main__":
    main()
