#!/usr/bin/python

import smtplib
import email.utils
from email import encoders
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
import boto3
import sys
import time
from datetime import datetime
from colorama import Fore, Back, Style
from config import *
import logging


logging.basicConfig(filename="access.log",
                    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s',
                    datefmt="%Y-%m-%d %H:%M:%S",
                    filemode='w')
logger=logging.getLogger()
logger.setLevel(logging.INFO)
def main():
    var=datetime.now().strftime("%y-%m-%d-%H-%M")
    session = boto3.Session(region_name=aws_region)
    con = session.client('ec2')
    ag = session.client('autoscaling')
    waiter_image = con.get_waiter('image_available')
    try:
        start_time = datetime.now()
        logger.info("<-------- Initiating quick deployment -------->")
        logger.info("creating ec2 AMI from primary server instance: %s" %(primary_aws_name_tag))
        imageId=create_ami(primary_server_ip, con, ami_prefix, var)
        logger.info("ec2 AMI created: %s" %(imageId))
        logger.info("Updating launch configuration with new AMI")
        #print (user_data)
        update_launchconfiguration(con, ag, imageId, aws_security_group, aws_instance_type, aws_subnet, aws_key, aws_name_tag, autoscaling_group, launch_configuration, user_data.decode())
        logger.info("launch configuration updated")
        logger.info("Triggering ec2 AMI quick deployment notification")
        mail_message="Quick deployment completed. ec2 AMI" + " " + imageId + " " + " has been updated on launch configuration."
        mailer(mail_message, SMTP_SERVER, SMTP_PORT, sender, password, recipient, subject)
        logger.info("<-------- quick deployment done -------->")
    except (Exception, e1):
        error1 = "main Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1, SMTP_SERVER, SMTP_PORT, sender, password, recipient, subject)
        sys.exit(0)    

def create_ami(primary_server_ip, con, ami_prefix, var):
    try:
        response = con.describe_instances(
            Filters = [
                {
                    'Name': 'ip-address',
                    'Values': [primary_server_ip]
                }
            ]
        )
        #print (response)
        instance_id = response['Reservations'][0]['Instances'][0]['InstanceId']
        #print (instance_id)
        response = con.create_image(
            InstanceId = instance_id,
            Name = ami_prefix+var,
            NoReboot = False
        )
        imageId = response['ImageId']
        print (imageId)
        logger.info("checking Image status of Imageid: "+imageId)
        waiter_image = con.get_waiter('image_available')
        waiter_image.wait(ImageIds = [imageId])
        logger.info("Image Available Imageid: "+imageId)
        return (imageId)
    except (Exception, e1):
        error1 = "create_ami Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1, SMTP_SERVER, SMTP_PORT, sender, password, recipient, subject)
        sys.exit(0)    

def update_launchconfiguration(con, ag, imageId, aws_security_group, aws_instance_type, aws_subnet, aws_key, aws_name_tag, autoscaling_group, launch_configuration, user_data):
    try:
        response = con.create_launch_template(
            LaunchTemplateName = 'copy-'+launch_configuration,
            LaunchTemplateData = {
                'ImageId': imageId,
                'KeyName': aws_key,
                'SecurityGroupIds': [aws_security_group],
                #   'NetworkInterfaces': [{
                #       'AssociatePublicIpAddress': True
                #      }],
                'InstanceType': aws_instance_type,
                'UserData': user_data
            }
        )       
    
        response = ag.update_auto_scaling_group(
            AutoScalingGroupName = autoscaling_group,
            LaunchTemplate = {
                'LaunchTemplateName': 'copy-'+launch_configuration,
                'Version': '1'
                }
        )
        response = con.delete_launch_template(
            LaunchTemplateName = launch_configuration

        )
        response = con.create_launch_template(
            LaunchTemplateName = launch_configuration,
            LaunchTemplateData = {
                'ImageId': imageId,
                'KeyName': aws_key,
                'SecurityGroupIds': [aws_security_group],
            #   'NetworkInterfaces': [{
            #       'AssociatePublicIpAddress': True
            #      }],
                'InstanceType': aws_instance_type,
                'UserData': user_data



            }
        )
        response = ag.update_auto_scaling_group(
            AutoScalingGroupName = autoscaling_group,
            LaunchTemplate = {
                'LaunchTemplateName': launch_configuration,
                'Version': '1'
                }
        )
        response = con.delete_launch_template(
            LaunchTemplateName = 'copy-'+launch_configuration

        )
    except (Exception, e1):
        error1 = "update_launchconfiguration Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        mailer(error1, SMTP_SERVER, SMTP_PORT, sender, password, recipient, subject)
        sys.exit(0)       
        
        #print (response)
def mailer(mail_message, SMTP_SERVER, SMTP_PORT, sender, password, recipient, subject):
    try:
        msg = MIMEMultipart()
        msg['subject'] = subject
        msg['To'] = ','.join(recipient)
        msg['From'] = sender
        part = MIMEText('text', "plain")
        message = mail_message
        part.set_payload(message)
        msg.attach(part)
        session = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        session.ehlo()
        session.starttls()
        session.ehlo
        session.login(sender, password)
        qwertyuiop = msg.as_string()
        session.sendmail(sender, recipient, qwertyuiop)
        session.quit()
    except (Exception, e1):
        error1 = "Error1: %s" % str(e1)
        print(Fore.RED + Back.GREEN +  error1 + Style.RESET_ALL)
        logger.error(error1)
        sys.exit(0)    
if __name__ == '__main__':

    main()



